import { Navigation } from './components/Navigation';
import { ClockPortal } from './components/ClockPortal';
import { TimeRelics } from './components/TimeRelics';
import { JournalBlog } from './components/JournalBlog';
import { EraQuiz } from './components/EraQuiz';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* Hero Section with Clock Portal */}
      <section id="home" className="pt-20">
        <ClockPortal />
      </section>

      {/* Time Relics Shop Section */}
      <section id="relics">
        <TimeRelics />
      </section>

      {/* Journal Blog Section */}
      <section id="journal">
        <JournalBlog />
      </section>

      {/* Interactive Era Quiz */}
      <section id="quiz">
        <EraQuiz />
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
