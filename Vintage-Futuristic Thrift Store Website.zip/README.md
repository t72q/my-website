
  # Vintage-Futuristic Thrift Store Website

  This is a code bundle for Vintage-Futuristic Thrift Store Website. The original project is available at https://www.figma.com/design/8ZSYW19gqnBZTszWS4iGNe/Vintage-Futuristic-Thrift-Store-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  